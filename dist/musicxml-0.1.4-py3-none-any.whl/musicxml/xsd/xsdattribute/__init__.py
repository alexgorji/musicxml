from .core import XSDAttribute
from .xsdattribute import *
